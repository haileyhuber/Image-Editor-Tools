package a7;

public class NoIntersectionException extends Exception {

	public NoIntersectionException() {
		super("Empty intersection");
	}
}
