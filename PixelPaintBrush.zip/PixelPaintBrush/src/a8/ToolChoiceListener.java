package a8;

public interface ToolChoiceListener {

	void toolChosen(String tool_name);
}
